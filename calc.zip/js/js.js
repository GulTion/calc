
var i=0;
function opennav() {
   
    if(i==0){
        document.getElementById('nav').style.width = '250px';
       return i=1;
    };
   if(i==1){
        document.getElementById('nav').style.width = '0px';
       return i=0;
    
   }
   
   
};
function getHistory(){
    return document.getElementById('history').innerHTML;
}
function printHistory(num){
    document.getElementById('history').innerHTML = num;
}
function getFormated(num){
  var n =  Number(num);
  var value= n.toLocaleString('en');
  return value;
}
function getNumber(num){
    return Number(num.replace(/,/g,''));
}
function getData(){
   return document.getElementById('data').innerHTML;
}
function printData(num){
    document.getElementById('data').innerHTML = getFormated(num);
}
var operator = document.getElementsByClassName('operator');
for(var a=0;a < operator.length;a++){
    operator[a].addEventListener('click',
    function(){
        if(this.id == 'clearall'){
            printData('0');
            printHistory('')
        }
        if(this.id == 'clear'){
            printData('0');

        }
        if(this.id == 'del'){
            var output = getNumber(getData()).toString();
            if(output){
            output = output.substr(0, output.length-1);
            printData(output);
            }
        }
    }
    )
}
var numbers = document.getElementsByClassName('nums');
for(var a=0;a < numbers.length;a++){
    numbers[a].addEventListener('click',function(){
        var output = getNumber(getData());
        
        if(output!= NaN){
            output = output+ this.innerHTML;
            printData(output);
        }
    })
}





